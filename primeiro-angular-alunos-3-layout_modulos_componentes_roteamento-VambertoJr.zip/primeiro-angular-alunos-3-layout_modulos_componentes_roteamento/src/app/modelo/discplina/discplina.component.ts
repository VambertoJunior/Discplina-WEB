import { Component } from '@angular/core';


@Component({
  selector: 'app-discplina',
  templateUrl: './discplina.component.html',
  styleUrls: ['./discplina.component.css']
})
export class DiscplinaComponent {


}
