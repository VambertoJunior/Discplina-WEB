import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscplinaComponent } from './discplina.component';

describe('DiscplinaComponent', () => {
  let component: DiscplinaComponent;
  let fixture: ComponentFixture<DiscplinaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DiscplinaComponent]
    });
    fixture = TestBed.createComponent(DiscplinaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
